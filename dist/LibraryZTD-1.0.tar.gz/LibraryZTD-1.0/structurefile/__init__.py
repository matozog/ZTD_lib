from structurefile import CSVFile
from structurefile import record
from structurefile import station
